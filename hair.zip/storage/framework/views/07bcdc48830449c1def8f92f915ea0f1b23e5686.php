<?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $order->order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="cursor: pointer; 
            <?php if($o->status == config('config.order.status.check-in')): ?> 
                <?php echo e('background: #7CB342; color: #fff;'); ?> 
            <?php elseif($o->status == config('config.order.status.check-out')): ?> 
                <?php echo e('background: #d9edfe; color: #000;'); ?> 
            <?php endif; ?>"  
            value="<?php echo e($o->id); ?>" class="list-order" id="order<?php echo e($o->id); ?>">
            <td>
                <?php echo e($o->id); ?>

            </td>
            
            <td>
                <?php echo e($o->customer->phone); ?>

            </td>
            <!-- <td style="font-weight: bold;">
                <?php echo e(($o->customer->full_name == '') ? 'Chưa điền thông tin' : $o->customer->full_name); ?>

            </td> -->
            <td>
                <?php echo e($o->time->time); ?>

            </td>
            <td>
                <?php $__currentLoopData = $o->orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($orderDetail->employee_id != ''): ?>
                        <p>
                            <span style="font-weight: bold;">
                                »
                            </span> <?php echo e($orderDetail->service->name); ?> + <?php echo e($orderDetail->employee->full_name); ?>

                        </p>
                    <?php else: ?>
                        <p>
                            <span style="font-weight: bold;">
                                »
                            </span> <?php echo e($orderDetail->service->name); ?> + <i>Chưa chọn</i>
                        </p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>
                <?php if($o->status == config('config.order.status.create')): ?>
                    Chưa check-in
                <?php elseif($o->status == config('config.order.status.check-in')): ?>
                    Đã check-in
                <?php else: ?>
                    Hoàn thành
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('.list-order').click(function() {
            $('.list-order').removeClass('active');
            $(this).addClass('active');
            var orderId = $(this).attr('value');
            $.get('admin/dat-lich/chi-tiet/' + orderId, function(data){
              $('#right').html(data);
            });
        });
    })
</script>
