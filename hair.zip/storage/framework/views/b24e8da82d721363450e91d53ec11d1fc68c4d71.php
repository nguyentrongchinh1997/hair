<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
		<script type="text/javascript">
			
			// if (id != '') {
			// 	var auto_refresh = setInterval(function (){
			// 	$('#load_tweets').load("danh-gia/load").fadeIn("slow");
			// 	}, 15000);
			// }
		   	var auto_refresh = setInterval(function (){
				$('#load-input').load("input").fadeIn("slow");
				}, 2000);
		   	var billId = $('#bill-id').val();
			if (billId != '') {
				var auto_refresh = setInterval(function (){
				$('#load_tweets').load("danh-gia/load").fadeIn("slow");
				}, 5000);
			}
		</script>
		<!-- <script type="text/javascript">
			$.get('danh-gia/load', function(data){
				$('#load_tweets').html(data);
			})
		</script> -->
	</head>
	<body>
		<div id="load-input">
			<input type="text" id="bill-id" value="<?php if(isset($bill)): ?><?php echo e($bill->id); ?><?php endif; ?>" name="">
		</div>
		<div id="load_tweets">
			<center>
				<img src="https://cdn1.mywork.com.vn/company-logo-medium/201702/5dc078b451f4.jpg">
			</center>
		</div>
		
			
	</body>
</html>