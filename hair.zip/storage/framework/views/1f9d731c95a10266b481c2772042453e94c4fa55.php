<center>
	<h1>MỜI ANH <?php echo e($bill->order->customer->full_name); ?></h1>
	<h3>XÁC NHẬN LẠI THÔNG TIN HÓA ĐƠN GIÚP CHÚNG EM</h3>
	<table>
		<tr>
			<td>Anh vui lòng chỉ thanh toán đúng số tiền<br><?php echo e($bill->price); ?></td>
			<td>
				<a href="danh-gia/?step=2">Xác nhận</a>
			</td>
		</tr>
	</table>
	<p>
		Nếu chưa đúng anh vui lòng báo lễ tân để chỉnh sửa giúp em nhé
	</p>
</center>