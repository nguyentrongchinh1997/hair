<style type="text/css">
    .btn-light{
        border: 1px solid #ced4da !important;
        outline: none;
    }
    table tr td {
        padding: 10px;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-left: 40px; margin-top: 40px">
        <div class="col-lg-12">
            <h2>DANH SÁCH THẺ HỘI VIÊN</h2>
            <?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>
        </div>
        
        <div class="col-lg-8">
            <button style="float: right; margin-bottom: 20px" type="button" class="btn btn-primary" data-toggle="modal" data-target="#cart">THÊM THẺ</button>
            <table class="table table-bordered" style="margin-top: 20px">
                <thead>
                    <tr>
                        <th scope="col">STT</th>
                        <th scope="col">Khách hàng</th>
                        <th scope="col">SĐT</th>
                        <th scope="col">Dịch vụ áp dụng</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Ngày hết hạn</th>
                    </tr>
                </thead>
                <tbody class="order-list">
                    <?php $stt = 0; ?>
                    <?php $__currentLoopData = $cardList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$stt); ?></td>
                            <td>
                                <?php echo e($card->customer->full_name); ?>

                            </td>
                            <td>
                                <?php echo e($card->customer->phone); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $card->cardDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        » <?php echo e($service->service->name); ?>

                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                
                            </td>
                            <td>
                                <?php echo e(date('d/m/Y', strtotime($card->end_time))); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="modal fade" id="cart">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">THÊM THẺ HỘI VIÊN</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route('card.add')); ?>">
                        <?php echo csrf_field(); ?>
                        <table style="width: 100%">
                            <tr>
                                <td>Khách hàng</td>
                                <td>:</td>
                                <td>
                                    <select name="customer_id" class="selectpicker form-control" data-live-search="true" data-width="fit" tabindex="-98">
                                        <?php $__currentLoopData = $customerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->phone); ?> (<?php echo e($customer->full_name); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Tên chương trình
                                </td>
                                <td>:</td>
                                <td>
                                    <input type="text" class="form-control" name="card_name">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Tặng %
                                </td>
                                <td>
                                    :
                                </td>
                                <td>
                                    <input type="number" class="form-control" name="percent">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Chi phí
                                </td>
                                <td>:</td>
                                <td>
                                    <input class="form-control" type="text" id="formattedNumberField" name="money">
                                </td>
                            </tr>
                            <tr>
                                <td>Thời gian bắt đầu</td>
                                <td>:</td>
                                <td>
                                    <input type="date" class="form-control" name="start_time">
                                </td>
                            </tr>
                            <tr>
                                <td>Thời gian kết thúc</td>
                                <td>:</td>
                                <td>
                                    <input type="date" class="form-control" name="end_time">
                                </td>
                            </tr>
                            
                        </table>
                        <div class="col-lg-12">
                            <label>Chọn dịch vụ</label>
                            <div class="row">
                                <?php $__currentLoopData = $serviceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4">
                                        <label>
                                            <input value="<?php echo e($service->id); ?>" type="checkbox" name="service[]"> <?php echo e($service->name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-lg-12" style="margin-top: 30px">
                            <center>
                                <button class="btn btn-primary" type="submit">XÁC NHẬN</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>