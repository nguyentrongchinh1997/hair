<!DOCTYPE html>
<html>
	<head>
		<title>Trang quản trị Admin</title>
		<base href="<?php echo e(asset('/')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap/css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/client/style.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('/font/fontawesome-free-5.10.0-web/css/all.css')); ?>" crossorigin="anonymous">
		<script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
  		<script src="<?php echo e(asset('/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/client/client.js')); ?>"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/client/slick.css')); ?>">
        <script src="<?php echo e(asset('/js/client/slick.js')); ?>"></script>
	</head>
	<body>
		<header>
			<?php if(session('thongbao')): ?>
				<div class="alert alert-success" style="margin-bottom: 0px; text-align: center;">
		        	<?php echo e(session('thongbao')); ?>

		        </div>
	        <?php endif; ?>
			<div class="row top-header">
				<div class="container">
					<center>
						<img src="<?php echo e(asset('/image/logo.webp')); ?>">
					</center>
				</div>
				
			</div>
			<div class="row menu">
				<div class="container">
					<div class="col-lg-12">
						<ul>
							<a href="<?php echo e(route('admin.home')); ?>">
								<li>
									<i class="fas fa-home"></i>
								</li>
							</a>
							<a href="">
								<li>DỊCH VỤ</li>
							</a>
							<a href="">
								<li>VỀ 30SHINE</li>
							</a>
							<a href="">
								<li>TUYỂN DỤNG</li>
							</a>
							<?php if(auth('customers')->check()): ?>
						        <a href="" style="float: right;">
									<li>Số dư: <?php echo e(number_format(auth('customers')->user()->balance)); ?><sup>đ</sup></li>
								</a>
						    <?php endif; ?>
						</ul>
					</div>
				</div>
			</div>
		</header>