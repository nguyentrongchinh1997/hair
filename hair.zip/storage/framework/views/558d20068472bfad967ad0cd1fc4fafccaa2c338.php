<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .rate{
            font-size: 100px;
            padding: 0px 10px;
            color: #ccc;
            font-weight: bold;
        }
        table tr td{
            text-align: center;
            padding: 0px 20px;
        }
        table{
            margin-top: 50px
        }
    </style>
    <script type="text/javascript">
        $(function(){
            // setTimeout(function(){
            //    window.location.href='danh-gia?step=3';
            // },10000);
            $('.rate').click(function(){
                $('.rate').css({"color":"#ccc"});
                $(this).css({"color":"yellow"});
                data = $(this).attr('data');
                billId = $('#bill-id').val();
                $.get('khach-hang/danh-gia/' + data + '/' + billId);
                $('#rate-result').html(data);
                $('.title-rate').show();
                window.location.href='danh-gia?step=3';
               //  setTimeout(function(){
               //     window.location.href='danh-gia?step=3';
               // },1500);
            })

        })
        
    </script>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <center>
            <h2>MỜI ANH <span style="color: red"><?php echo e($bill->order->customer->full_name); ?></span></h2>
            <h4>
                ĐÁNH GIÁ CHẤT LƯỢNG DỊCH VỤ GIÚP CHÚNG EM
            </h4>
            <table>
                <tr>
                    <?php $__currentLoopData = $rateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <i data='<?php echo e($rate->id); ?>' class="rate <?php echo e($rate->icon_class); ?>"></i>
                            
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $rateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td>
                           <span><?php echo e($rate->name); ?></span>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </table>
            <input type="hidden" id="bill-id" value="<?php echo e($bill->id); ?>" name="">
            <p>
                <span class="title-rate" style="display: none;">Anh đã chọn: <span style="font-weight: bold; color: green" id="rate-result"></span></span>
            </p>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.pages.rate.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>