<?php $stt = 0; ?>
<?php $__currentLoopData = $customerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="list-customer" onclick="customerDetail(<?php echo e($customer->id); ?>)" id="customer<?php echo e($customer->id); ?>" style="cursor: pointer;">
        <th scope="row"><?php echo e(++$stt); ?></th>
        <td>
            <?php echo e($customer->full_name); ?>

        </td>
        <td>
            <?php echo e($customer->phone); ?>

        </td>
        <td>
            <?php echo e(date('d/m/Y', strtotime($customer->birthday))); ?>

        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
