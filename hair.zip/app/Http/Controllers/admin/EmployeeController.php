<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Service\admin\EmployeeService;

class EmployeeController extends Controller
{
	protected $adminService;

    public function __construct(AdminService $adminService)
    {
        $this->adminService = $adminService;
    }

    public function employeeAddView()
    {
    	return view('admin.pages.employee.add');
    }

    public function employeeListView()
    {
        return view('admin.pages.employee.list', $this->adminService->employeeListView());
    }

    public function employeeEditView($id)
    {
        return view('admin.pages.employee.edit', $this->adminService->oldDataEmployee($id));
    }

    public function employeeEdit(Request $request, $id)
    {
        $check = $this->adminService->employeeEdit($request, $id);
        
        if ($check == 0) {
            return back()->with('error', 'Số điện thoại đã bị trùng');
        } else {
            return back()->with('thongbao', 'Sửa thành công');
        }
    }

    public function salary($employeeId)
    {
        return view('admin.pages.employee.salary_list', $this->adminService->salary($employeeId));
    }

    public function postSalary(Request $request, $employeeId)
    {
        return view('admin.pages.employee.salary_list', $this->adminService->postSalary($employeeId, $request));
    }
}
