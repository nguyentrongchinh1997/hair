<?php $__env->startSection('content'); ?>
    <div class="row employee-add" style="padding-left: 40px; padding-top: 40px">
        <div class="col-lg-10">
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </div>
            <?php endif; ?>
            <?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <h2>DANH SÁCH NHÂN VIÊN</h2>
            <!-- Button to Open the Modal -->
          <button style="float: right;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
            Thêm nhân viên
          </button><br>
          <!-- The Modal -->
          <div class="modal fade" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Thêm nhân viên</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    
                    <!-- Modal body -->
                    <div class="modal-body">
                        <form method="post" action="<?php echo e(route('employee.add')); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <table>
                                <tr>
                                    <td>
                                        Tên nhân viên
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" required="required" value="<?php echo e(old('full_name')); ?>" name="full_name">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Số điện thoại
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" required="required" name="phone">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Làm dịch vụ
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <select name="type" class="form-control">
                                            <?php $__currentLoopData = $serviceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Địa chỉ
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <input value="<?php echo e(old('address')); ?>" type="text" class="form-control" name="address">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Hoa hồng (%)
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <input type="number" value="<?php echo e(old('percent')); ?>" name="percent" class="form-control">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Lương (vnđ)
                                    </td>
                                    <td>:</td>
                                    <td>
                                        <input id="formattedNumberField" type="text" value="<?php echo e(old('salary')); ?>" name="salary" class="form-control">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Mật khẩu đăng nhập 
                                    </td>
                                    <td>
                                        :
                                    </td>
                                    <td>
                                        <input type="password" value="<?php echo e(old('password')); ?>" name="password" class="form-control">
                                    </td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <input class="btn btn-primary" value="Thêm" type="submit" name="">
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                    
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                
                </div>
            </div>
          </div><br>
            <table class="table table-striped">
              <thead>
                <tr>
                    <th scope="col">STT</th>
                    <th scope="col">Tên</th>
                    <th scope="col">Số điện thoại</th>
                    <th scope="col">Vị trí</th>
                    <th scope="col">Địa chỉ</th>
                    <th scope="col">Phần trăm hưởng</th>
                    <th scope="col">Trạng thái làm việc</th>
                    <th scope="col">Lương cứng</th>
                    <th scope="col">Sửa</th>
                </tr>
              </thead>
              <tbody>
                <?php $stt = 0; ?>
                <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e(++$stt); ?></th>
                        <td style="font-weight: bold;">
                            <a href="<?php echo e(route('salary.list', ['id' => $employee->id])); ?>">
                                <?php echo e($employee->full_name); ?>

                            </a>
                        </td>
                        <td>
                            <?php echo e($employee->phone); ?>

                        </td>
                        <td>
                            <?php echo e($employee->service->name); ?>

                        </td>
                        <td>
                            <?php echo e($employee->address); ?>

                        </td>
                        <td style="text-align: center;">
                            <?php echo e($employee->percent); ?> %
                        </td>
                        <td style="text-align: center;">
                            <span style="<?php echo e(($employee->status == config('config.employee.status.doing')) ? 'color: #4c9d2f; font-weight: bold;' : 'color: red; font-weight: bold;'); ?>">
                                <?php echo e(($employee->status == config('config.employee.status.doing')) ? 'Đang làm việc' : 'Đã nghỉ làm'); ?>

                            </span>
                        </td>
                        <td style="text-align: right;; font-weight: bold;">
                            <?php echo e(number_format($employee->salary)); ?><sup>đ</sup>
                        </td>
                        <td>
                            <button onclick="editEmployee(<?php echo e($employee->id); ?>)" type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit">
                                Sửa
                            </button>
                            <!-- <a href="<?php echo e(route('employee.edit', ['id' => $employee->id])); ?>">
                                Sửa
                            </a> -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div class="modal fade" id="edit">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title">Sửa nhân viên</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body edit-employee">
                        
                    </div>
                    
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                    
                  </div>
                </div>
            </div>
        </div>
        <div class="col-lg-10">
            <style type="text/css">
                .pagination{
                    float: right;
                }
            </style>
            <?php echo e($employeeList->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>