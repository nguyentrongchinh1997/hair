<!DOCTYPE html>
<html>
	<head>
		<title>Salon Mobile</title>
	</head>
	<body>

	</body>
</html>