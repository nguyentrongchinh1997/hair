<?php $__env->startSection('content'); ?>
<div class="row login" style="padding-left: 40px; padding-top: 40px">
	<div class="col-lg-6">
		<h3>Đăng nhập</h3>
		<!-- <input type="file" class="test" onchange="my()" name="">
		<script type="text/javascript">
			function my(){
				var x = $(".test").val();
				alert(x);
			}
		</script> -->
		<?php if(session('thongbao')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('thongbao')); ?>

            </div>
        <?php endif; ?>
		<form method="post" action="<?php echo e(route('login')); ?>">
		<?php echo e(csrf_field()); ?>

			<table>
				<tr>
					<td>
						Tên đăng nhập
					</td>
					<td>
						:
					</td>
					<td>
						<input type="text" class="form-control" required="required" name="username">
					</td>
				</tr>
				<tr>
					<td>
						Mật khẩu
					</td>
					<td>
						:
					</td>
					<td>
						<input type="password" required="required" class="form-control" name="password">
					</td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td>
						<input type="submit" class="btn btn-primary" value="Đăng nhập" name="">
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>