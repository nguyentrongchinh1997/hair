<?php $__env->startSection('content'); ?>
<div class="row employee-add" style="padding-left: 40px; padding-top: 40px">
	<div class="col-lg-6">
		<h3>Thêm dịch vụ</h3>
		<?php if(count($errors)>0): ?>
	        <div class="alert alert-danger">
	            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <?php echo e($err); ?><br>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
	        </div>
	    <?php endif; ?>
	    <?php if(session('thongbao')): ?>
	        <div class="alert alert-success">
	            <?php echo e(session('thongbao')); ?>

	        </div>
	    <?php endif; ?>
		<form method="post" action="<?php echo e(route('service.add')); ?>">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<table>
				<tr>
					<td>
						Tên dịch vụ
					</td>
					<td>
						:
					</td>
					<td>
						<input type="text" class="form-control" required="required" value="<?php echo e(old('name')); ?>" name="name">
					</td>
				</tr>
				<tr>
					<td>
						Giá
					</td>
					<td>
						:
					</td>
					<td>
						<input type="text" id="formattedNumberField" class="form-control" required="required" name="price">
					</td>
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td>
						<input class="btn btn-primary" value="Thêm" type="submit" name="">
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>