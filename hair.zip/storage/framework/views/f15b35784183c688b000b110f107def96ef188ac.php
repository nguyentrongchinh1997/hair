<!DOCTYPE html>
<html>
    <head>
        <title>Đánh giá của khách hàng</title>
        <base href="<?php echo e(asset('/')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/font/fontawesome-free-5.10.0-web/css/all.css')); ?>">
        <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
        <!-- <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> -->

    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
