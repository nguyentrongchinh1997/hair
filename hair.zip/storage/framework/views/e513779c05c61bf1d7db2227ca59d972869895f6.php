<div class='col-lg-3'>
    <p style="font-size: 25px">Tổng giá</p>
</div>
<div class='col-lg-1'>
    :
</div>
<div class='col-lg-8'>
    <p style='font-weight: bold; font-size: 25px; color: #007bff'>
       <?php echo e($total); ?><sup>đ</sup> 
    </p>
</div>