<?php $stt = 0; $total = 0;?>
<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $customer->bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($bill->order->date == $date): ?>
        <tr style="cursor: pointer; <?php if($bill->status == config('config.order.status.check-out')): ?> <?php echo e('background: #d9edfe; color: #000'); ?> <?php endif; ?>" value="<?php echo e($bill->id); ?>" class="list-bill" id="bill<?php echo e($bill->id); ?>" value="<?php echo e($bill->id); ?>" class="list-bill" id="bill<?php echo e($bill->id); ?>"> 
            <script type="text/javascript">
                $(document).ready(function(){
                    $('.list-bill').click(function() {
                        $('.list-bill').removeClass('active');
                        $(this).addClass('active');
                        var billId = $(this).attr('value');
                        if (billId != '') {
                            $.get('admin/hoa-don/chi-tiet/' + billId, function(data){
                              $('.right').html(data);
                          });
                        }
                      });
                })
            </script>       
            <td><?php echo e(++$stt); ?></td>  
            <td>
                <?php echo e($bill->customer->phone); ?>

            </td>
            <td>
                <?php echo e(($bill->customer->full_name == '') ? 'Chưa điền thông tin' : $bill->customer->full_name); ?>

            </td>              
            
            <td>
                <?php if($bill->status == config('config.order.status.check-in')): ?>
                    <span style="color: red">Chưa thanh toán</span>
                <?php else: ?>
                    <span style="color: green">Đã thanh toán</span>
                <?php endif; ?>
            </td>
            <td style="text-align: right; font-weight: bold;">
                <?php $tong = 0; ?>
                <?php $__currentLoopData = $bill->billDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicePrice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $tong = $tong + $servicePrice->money; 
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $total = $total + $tong;
                ?>
                <?php echo e(number_format($tong)); ?><sup>đ</sup>
            </td>
        </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
