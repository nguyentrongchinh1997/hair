<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="<?php echo e(asset('/font/fontawesome-free-5.10.0-web/css/all.css')); ?>" crossorigin="anonymous">
		<script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
		<style type="text/css">
			.rate{
				font-size: 30px;
				padding: 0px 10px;
				color: #ccc;
				font-weight: bold;
			}
		</style>
		<script type="text/javascript">
			$('.rate').click(function(){
				$('.rate').css({"color":"#ccc"});
				$(this).css({"color":"yellow"});
				data = $(this).attr('data');
				billId = $('#bill-id').val();
				$.get('khach-hang/danh-gia/' + data + '/' + billId);
				$('#rate-result').html(data);
				$('.title-rate').show();
			})
			$('.comment').click(function(){
				if($(this).is(":checked")) {
					comment = $(this).val();
					billId = $('#bill-id').val();
					$.get('khach-hang/binh-luan/' + comment + '/' + billId);
				}
			})
		</script>
	</head>
	<body>
		
		<center>
			<h1>Mời Anh <span style="color: red"><?php echo e($bill->order->customer->full_name); ?></span> Đánh Giá</h1>
			<a href="danh-gia/?page=1">next</a>
			<i data='tệ' class="rate far fa-sad-cry"></i>
			<i data='bình thường' class="rate far fa-frown-open"></i>
			<i data='hài lòng' class="rate far fa-smile"></i>
			<i data='tuyệt vời' class="rate far fa-grin-beam"></i>
			<input type="hidden" id="bill-id" value="<?php echo e($bill->id); ?>" name="">
			<p>
				<span class="title-rate" style="display: none;">Anh đã chọn: <span style="font-weight: bold; color: green" id="rate-result"></span></span>
			</p>
			<h1>30SHINE NÊN CẢI THIỆN ĐIỀU GÌ ĐỂ ANH HÀI LÒNG HƠN?</h1>
			<table>
				<tr>
					<td>
						<label>
							<input class="comment" value="Tất cả đều tốt, không có góp ý gì;" type="checkbox" name="">
							Tất cả đều tốt, không có góp ý gì
						</label>
					</td>
					<td>
						<label>
							<input class="comment" type="checkbox" value="Chất lượng cắt và kiểu tóc;" name="">
							Chất lượng cắt và kiểu tóc
						</label>
					</td>
				</tr>
				<tr>
					<td>
						<label>
							<input class="comment" value="Thái độ phục vụ;" type="checkbox" name="">
							Thái độ phục vụ
						</label>
					</td>
					<td>
						<label>
							<input class="comment" value="Thời gian chờ đợi;" type="checkbox" name="">
							Thời gian chờ đợi
						</label>
					</td>
				</tr>
				<tr>
					<td>
						<label>
							<input class="comment" value="Nhân viên bớt làm ồn trong khi phục vụ;" type="checkbox" name="">
							Nhân viên bớt làm ồn trong khi phục vụ
						</label>
					</td>
					<td>
						<label>
							<input class="comment" value="Cảm thấy bị làm phiền bởi việc tư vấn dịch vụ/bán hàng;" type="checkbox" name="">
							Cảm thấy bị làm phiền bởi việc tư vấn dịch vụ/bán hàng
						</label>
					</td>
				</tr>
			</table>
		</center>
		
	</body>
</html>