
    <div style="margin: auto; max-width: 500px">
        <!-- <h2 style="text-align: center;">HÓA ĐƠN</h2> -->
        <form method="post" action="<?php echo e(route('finish', ['id' => $billId])); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" id="bill-id" value="<?php echo e($billId); ?>">
            <?php if($bill->sale_detail != ''): ?>
                <div class="row">
                    <table style="width: 100%">
                        <tr>
                            <td style="width: 40%">
                                Nội dung Sale
                            </td>
                            <td style="width: 10%">:</td>
                            <td style="width: 50%">
                                <?php echo e($bill  ->sale_detail); ?>

                            </td>
                        </tr>
                    </table>
                </div>
            <?php endif; ?>
            <table style="width: 100%" class="update-rate">
                <!-- <tr>
                    <td style="width: 40%">
                        Khách hàng
                    </td>
                    <td style="width: 10%">:</td>
                    <td style="width: 50%">
                        <?php echo e($bill->customer->full_name); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        SĐT
                    </td>
                    <td>:</td>
                    <td>
                        <?php echo e($bill->customer->phone); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Thu ngân
                    </td>
                    <td>:</td>
                    <td>
                        <?php echo e($bill->employee->full_name); ?>

                    </td>
                </tr> -->
                <tr>
                    <td style="width: 40%">
                        Đánh giá
                    </td>
                    <td style="width: 10%">:</td>
                    <td class="rate-customer" style="font-weight: bold; width: 50%">
                        <?php if($bill->rate_id != ''): ?>
                            <span><?php echo e($bill->rate->name); ?></span>
                        <?php else: ?>
                            <i>Khách chưa đánh giá</i>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        Góp ý của khách
                    </td>
                    <td>:</td>
                    <td class="comment-customer" style="font-weight: bold;">
                        <?php if($bill->rate_id != ''): ?>
                            <span><?php echo e($bill->comment); ?></span>
                        <?php else: ?>
                            <i>Khách chưa góp ý</i>
                        <?php endif; ?>
                    </td>
                </tr>

            </table>
            <table id="list-service">
                <tr>
                    <th>Dịch vụ</th>
                    <th>Thợ</th>
                    <th>Giá</th>
                    <th>Ghi chú</th>
                </tr>
                <?php $totalPrice = 0 ?>
                <?php $__currentLoopData = $serviceListUse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($service->service_id != ''): ?> 
                                <?php echo e($service->service->name); ?>

                            <?php else: ?>
                                <?php echo e($service->other_service); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($service->employee->full_name); ?>

                        </td>
                        <td style="text-align: right;">
                            <?php echo e(number_format($service->money)); ?><sup>đ</sup>
                        </td>
                        <td></td>
                    </tr>
                    <?php $totalPrice = $totalPrice + $service->money ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($bill->sale != 0): ?>
                    <tr>
                        <td colspan="3" style="text-align: right;">
                            <?php echo e(number_format($bill->sale)); ?><sup>đ</sup>
                        </td>
                        <td>Sale</td>
                    </tr>
                <?php endif; ?>
                <?php if($bill->status != config('config.order.status.check-out')): ?>
                    <tr>
                        <td colspan="3" style="text-align: right;">
                            <?php echo e(number_format($bill->customer->balance)); ?><sup>đ</sup>
                        </td>
                        <td>Số dư</td>
                    </tr>
                    <tr>
                        <?php 
                            $balance = $bill->customer->balance;
                            $total = $totalPrice - $bill->sale;
                        ?>
                        <?php if($balance >= $total): ?>
                            <td style="text-align: right; font-size: 25px; color: #007bff; font-weight: bold;" colspan="3">0 <sup>đ</sup></td>
                        <?php else: ?>
                            <td style="text-align: right; font-size: 25px; color: #007bff; font-weight: bold;" colspan="3">
                                <?php echo e(number_format($total - $balance)); ?><sup>đ</sup>
                            </td>
                        <?php endif; ?>
                        <td>
                            Cần thanh toán
                        </td>
                    </tr>
                <?php endif; ?>
            </table>
            <br>
            <?php if($bill->status != config('config.order.status.check-out')): ?>
                <center>
                    <input type="submit" value="Kết thúc" class="btn btn-primary" name="">
                    <a id="update-rate" style="background: #727272; border: 0px; cursor: pointer; color: #fff" class="btn btn-primary">
                        Cập nhật đánh giá
                    </a>
                    <script type="text/javascript">
                        $(function(){
                            $('#update-rate').click(function(){
                                billId = $('#bill-id').val();
                                $.get('admin/hoa-don/danh-gia/' + billId, function(data){
                                    $('.update-rate').html(data);
                                })
                            })
                        })
                    </script>
                </center>
            <?php endif; ?>
        </form>
    </div>
