        <footer>
        	<div class="container">	
	           <div class="row">
		           	<div class="col-lg-7">
		           		<p>
		           			CÔNG TY CỔ PHẦN TMDV 30Shine82
		           		</p>
		           		<p>
		           			Trần Đại Nghĩa, P. Đồng Tâm, Q. Hai Bà Trưng, HN
		           		</p>
		           		<p>
		           			Số giấy chứng nhận kinh doanh: 010.7467.693
		           		</p>
		           		<p>
		           			Ngày cấp : 08/06/2016
		           		</p>
		           		<p>
		           			Nơi cấp : Sở kế hoạch đầu tư TP Hà Nội
		           		</p>
		           		<p>
		           			Chính sách bảo mật thông tin
		           		</p>
		           		<p class="time-word">
		           			Giờ phục vụ 8h30 - 21h30 (kể cả thứ 7, CN)
		           		</p>
		           		<p>
		           			<b>
		           				Hotline góp ý chất lượng Dịch vụ:
		           			</b>
		           			
		           		</p>
		           		<p style="margin-top: 10px">
		           			<img src="https://30shine.com/images/hl.png" width="200px">
		           		</p>
		           		 

		           	</div>
	           </div>
	        </div>
        </footer>
    </body>
</html>