<?php $__env->startSection('content'); ?>
<!-- <script type="text/javascript">
    setTimeout(function(){
        var href = 'danh-gia';
       window.location.href = href;
   },10000);
</script> -->
<script type="text/javascript">
    setTimeout(function(){
        location.reload();
    },5000);
    $(function(){
        billId = $('#bill-id').val();

        if (billId == 0) {
            window.location.href = 'rate';
        }
    })
</script>
<style type="text/css">
    table tr td {
        font-size: 30px;
    }
</style>
<div class="container">
    <input type="hidden" id="bill-id" value="<?php if(isset($bill)): ?><?php echo e($bill->id); ?><?php else: ?><?php echo e('0'); ?><?php endif; ?>">
    <div id="load-input">
        
    </div>
    <div class="col-xs-12 col-sm-12 col-lg-12">
        <h2 style="text-align: center;">
            MỜI ANH <?php echo e(mb_strtoupper($bill->customer->full_name, 'UTF-8')); ?>

        </h2>
        <h4 style="text-align: center;">XÁC NHẬN LẠI THÔNG TIN HÓA ĐƠN GIÚP CHÚNG EM</h4>
        <table style="width: 100%; background: #F9FBE7;">
            <tr>
                <td style="text-align: center; padding: 10px">Anh vui lòng chỉ thanh toán đúng số tiền<br>
                    <span  style="color: red; font-weight: bold; font-size: 30px">
                        <?php echo e(number_format($sum)); ?> Đ
                        
                    </span>
                </td>
                <td style="text-align: right; padding: 10px">
                    <a class="btn btn-primary" href="danh-gia/?step=2"><i class="fas fa-check"></i> XÁC NHẬN ĐÚNG</a>
                </td>
            </tr>
        </table><br>
        <p style="color: orange; text-align: center;">
            Nếu chưa đúng anh vui lòng báo lễ tân để chỉnh sửa giúp em nhé
        </p>
        <table style="width: 100%">
            <?php $stt = 0; ?>
            <?php $__currentLoopData = $billDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php $sothutu = ++$stt; ?>
                        <?php echo e($sothutu); ?>.
                        <?php if($bill1->service_id == ''): ?> 
                            <?php echo e($bill1->other_service); ?>

                        <?php else: ?>
                            <?php echo e($bill1->service->name); ?>

                        <?php endif; ?>
                    </td>
                    <td style="text-align: right;">
                        <?php echo e(number_format($bill1->money)); ?> Đ
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($bill->sale != ''): ?>
                <tr>
                    <td><?php echo e($sothutu + 1); ?>. Được tặng</td>
                    <td style="text-align: right; color: red">
                        <?php echo e(number_format($bill->sale)); ?> Đ
                    </td>
                </tr>
            <?php endif; ?>
        </table>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.pages.rate.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>