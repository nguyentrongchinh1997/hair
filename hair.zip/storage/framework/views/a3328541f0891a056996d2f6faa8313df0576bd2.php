<tr id="row<?php echo e($data->id); ?>"> 
    <td><?php echo e($data->service->name); ?></td> 
    <td><?php echo e($data->employee->full_name); ?></td>
    <td>
        <?php if($data->assistant_id != ''): ?>
            <?php echo e($data->employeeAssistant->full_name); ?>

        <?php endif; ?>
    </td>
    <td style="text-align: right">
        <?php echo e(number_format($data->money)); ?><sup>đ</sup>
    </td>
    <td>
        <i onclick="xoa(<?php echo e($data->id); ?>)" style="cursor: pointer; color: red" class="fas fa-times" id="close<?php echo e($data->id); ?>"></i>
    </td>
</tr>
