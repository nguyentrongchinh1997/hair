@include('client.layouts.header')
@yield('content')
@include('client.layouts.footer')