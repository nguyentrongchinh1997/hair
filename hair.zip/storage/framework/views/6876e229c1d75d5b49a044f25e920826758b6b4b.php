<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-2" style="padding: 0px">
        <input style="display: none;" class="radio-stylist1" id="stylist<?php echo e($stylist->id); ?>" type="checkbox" value="<?php echo e($stylist->id); ?>" name="stylist[]">
        <img onclick="optionStylist(<?php echo e($stylist->id); ?>)" class="thumnail-stylist avatar-stylist<?php echo e($stylist->id); ?>" src="<?php echo e(asset('/image/default.png')); ?>" width="100%" style="border-radius: 100px; padding: 5px; border: 4px solid #727272">
    </div>
    <div class="col-lg-10">
        <p>
            <?php echo e(mb_strtoupper($stylist->full_name, 'UTF-8')); ?>

        </p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>