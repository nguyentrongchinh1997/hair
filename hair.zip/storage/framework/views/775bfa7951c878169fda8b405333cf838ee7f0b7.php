<tr>
    <td style="width: 40%">
        Đánh giá
    </td>
    <td style="width: 10%">:</td>
    <td class="rate-customer" style="font-weight: bold; width: 50%">
        <?php if($bill->rate_id != ''): ?>
            <span><?php echo e($bill->rate->name); ?></span>
        <?php else: ?>
            <i>Khách chưa đánh giá</i>
        <?php endif; ?>
    </td>
</tr>
<tr>
    <td>
        Góp ý của khách
    </td>
    <td>:</td>
    <td class="comment-customer" style="font-weight: bold;">
        <?php if($bill->rate_id != ''): ?>
            <span><?php echo e($bill->comment); ?></span>
        <?php else: ?>
            <i>Khách chưa góp ý</i>
        <?php endif; ?>
    </td>
</tr>