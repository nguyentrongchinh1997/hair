<div class="col-lg-12">
	<label>
        <b>CHỌN STYLIST (nếu muốn):</b>
    </label>
</div>

	<?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-lg-6">
			<p>
				<input type="radio" value="<?php echo e($employee->id); ?>" class="employee" name="employee">
				<i class="far fa-user-circle"></i> <?php echo e($employee->full_name); ?>

			</p>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('script'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/client/slick.css')); ?>">
    <script src="<?php echo e(asset('/js/client/slick.js')); ?>"></script>
<?php $__env->stopSection(); ?>