<!DOCTYPE html>
<html>
    <head>
        <title>Trang quản trị Admin</title>
        <base href="<?php echo e(asset('/')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/font/fontawesome-free-5.10.0-web/css/all.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/admin/style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/admin/choosen.css')); ?>">  
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">

    </head>
    <body>
        <header>
            <div class="row menu">
                <div class="col-lg-12">
                    <ul>
                        <a href="<?php echo e(route('order.list')); ?>">
                            <li <?php if(Request::is('admin/dat-lich/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                LỊCH ĐẶT
                            </li>
                        </a>
                        <a href="<?php echo e(route('bill.list')); ?>">
                            <li <?php if(Request::is('admin/hoa-don/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                HÓA ĐƠN
                            </li>
                        </a>
                        <a href="<?php echo e(route('service.list')); ?>">
                            <li <?php if(Request::is('admin/dich-vu/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                DỊCH VỤ
                            </li>
                        </a>
                        <a href="<?php echo e(route('customer.list')); ?>">
                            <li <?php if(Request::is('admin/khach-hang/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                QL.KHÁCH HÀNG
                            </li>
                        </a>
                        <a href="<?php echo e(route('employee.list')); ?>">
                            <li <?php if(Request::is('admin/nhan-vien/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                QL.NHÂN VIÊN
                            </li>
                        </a>
                        <a href="<?php echo e(route('rate.list')); ?>">
                            <li <?php if(Request::is('admin/danh-gia/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                ĐÁNH GIÁ
                            </li>
                        </a>
                        <a href="<?php echo e(route('cart.list')); ?>">
                            <li <?php if(Request::is('admin/the/danh-sach')): ?> <?php echo e("class=menu-active"); ?> <?php endif; ?>>
                                QL.THẺ
                            </li>
                        </a>

                        <?php if(auth()->check()): ?>
                            <a style="float: right;" href="<?php echo e(route('logout')); ?>">
                                <li>
                                    Đăng xuất
                                </li>
                            </a>
                            <a style="float: right;">
                                <li>
                                    <?php echo e(auth()->user()->name); ?>

                                </li>
                            </a>
                        <?php elseif(auth('employees')->check()): ?>
                            <a style="float: right;" href="<?php echo e(route('logout')); ?>">
                                <li>
                                    Đăng xuất
                                </li>
                            </a>
                            <a style="float: right;">
                                <li>
                                    <?php echo e(auth('employees')->user()->full_name); ?>

                                </li>
                            </a>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </header>
        