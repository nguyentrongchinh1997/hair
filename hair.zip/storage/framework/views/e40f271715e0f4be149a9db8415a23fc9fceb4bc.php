<?php $__env->startSection('content'); ?>
    <div class="row" style="padding-left: 40px; padding-top: 40px">
        <div class="col-lg-12">
            <h2>
                Bảng lương - <?php echo e($employee->full_name); ?>

            </h2><hr>
            <form method="post" action="<?php echo e(route('salary.list.post', ['id' => $employee->id])); ?>">
                <?php echo csrf_field(); ?>
                <table>
                    <tr>
                        <td>
                            <select name="month" class="form-control">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option <?php if($i == $month): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php if($i < 10): ?> 0<?php echo e($i); ?> <?php else: ?> <?php echo e($i); ?> <?php endif; ?>">
                                        Tháng <?php echo e($i); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        <td>
                            <select name="year" class="form-control">
                                <?php for($i = 2019; $i <= date('Y'); $i++): ?>
                                    <option <?php if($i == $year): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo e($i); ?>">
                                        Năm <?php echo e($i); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        <td>
                            <input value="Xem lương" class="btn btn-primary" type="submit" name="">
                        </td>
                    </tr>
                </table>
            </form><br>
            <div class="col-lg-7" style="padding: 0px">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">STT</th>
                            <th scope="col">Dịch vụ</th>
                            <th scope="col">Giá</th>
                            <th scope="col">Đánh giá</th>
                            <th scope="col">Chiết khấu (%)</th>
                            <th scope="col">Hoa hồng (vnd)</th>
                            <th scope="col">Ngày</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $stt = 0; $tong = 0; ?> 
                        <?php $__currentLoopData = $billDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($service->bill->status == config('config.order.status.check-out')): ?>
                                <tr>
                                    <th scope="row"><?php echo e(++$stt); ?></th>
                                    <td>
                                        <?php if($service->service_id != ''): ?>
                                            <?php 
                                                $percentService = $service->service->percent;
                                            ?>
                                            <?php echo e($service->service->name); ?>

                                        <?php else: ?>
                                            <?php 
                                                $percentService = $service->other_service_percent;
                                            ?> 
                                            <?php echo e($service->other_service); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: right; font-weight: bold;">
                                        <?php echo e(number_format($service->money)); ?><sup>đ</sup>
                                    </td>
                                    <td>
                                        <?php echo e($service->bill->rate_id); ?> - <?php echo e($service->bill->rate->name); ?>

                                    </td>
                                    <td style="text-align: center;">
                                        <?php if($service->bill->rate->type == config('config.rate.type.substract')): ?>

                                            <?php
                                                $percentRate = $service->bill->rate->percent;
                                                $percentTotal = $percentService + $service->employee->percent - $percentRate;
                                            ?>
                                            <?php echo e($percentTotal); ?>

                                        <?php else: ?>
                                            <?php 
                                                $percentRate = $service->bill->rate->percent;
                                                $percentTotal = $percentService + $service->employee->percent + $percentRate;
                                            ?>
                                            <?php echo e($percentTotal); ?>

                                        <?php endif; ?>

                                        
                                    </td>
                                    <td style="text-align: right; font-weight: bold;">
                                        <?php echo e(number_format($percentTotal/100 * $service->money)); ?><sup>đ</sup>
                                        <?php 
                                            $tong = $tong + ($percentTotal/100 * $service->money);
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo e(date('d/m/Y', strtotime($service->date))); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="6" style="text-align: right; font-weight: bold; font-size: 20px; color: #007bff">
                                    Tổng: <?php echo e(number_format($tong)); ?><sup>đ</sup>
                                </td>
                                <td></td>
                            </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>