<?php $__env->startSection('content'); ?>
	<div class="row" style="padding-left: 40px; margin-top: 20px">
		<div class="col-lg-6">
			<h2>QUẢN LÝ ĐÁNH GIÁ</h2>
			<?php if(session('thongbao')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('thongbao')); ?>

                </div>
            <?php endif; ?>
			<table class="rate">
				<tr>
					<td>Tên</td>
					<td>
						Phần trăm
					</td>
					<td>
						Ghi chú
					</td>
					<td>
						Sửa
					</td>
				</tr>
				<?php $__currentLoopData = $rateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<form method="post" action="<?php echo e(route('rate.post', ['id' => $rate->id])); ?>">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<tr>
							<td>
								<?php echo e($rate->name); ?>

							</td>
							<td>
								<input type="number" class="form-control" value="<?php echo e($rate->percent); ?>" name="percent">
							</td>
							<td style="font-weight: bold;">
								<?php if($rate->type == config('config.rate.type.substract')): ?>
									<span>-<?php echo e($rate->percent); ?>%</span>
								<?php else: ?>
									<span>+<?php echo e($rate->percent); ?>%</span>
								<?php endif; ?>
							</td>
							<td>
								<input class="btn btn-primary" value="Sửa" type="submit" name="">
							</td>
						</tr>
					</form>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>