<script type="text/javascript">
    function addCommas(nStr)
    {
        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }
    $('#price-dif, #sale').keyup(function(event) {
      // skip for arrow keys
      if(event.which >= 37 && event.which <= 40) return;
      // format number
      $(this).val(function(index, value) {
        return value
        .replace(/\D/g, "")
        .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        ;
      });
    });
    $('#sale').focus(function(){
        $('#sale').val('');
    })
    // $('.add-sale').click(function(){
    //     bill_id = $('#bill_id').val();
    //     sale_detail = $('#sale_detail').val();
    //     sale = $('#sale').val();
    //     if (sale_detail == '') {
    //         alert('Cần điền nội dung quà tặng');
    //     } else if (sale == '') {
    //         alert('Cần điền số tiền muốn tặng');
    //     } else {
    //         $.get('admin/hoa-don/giam-gia/cap-nhat/' + bill_id + '?sale=' + sale + '&saleDetail=' + sale_detail , function(data){
    //             if (data == '') {
    //                 alert('Hóa đơn được hoàn thành. Bạn không được thêm quà tặng.')
    //             } else {
    //                 alert('Cập nhập thành công');
    //             }
    //         });
    //     }
    // })
</script>
<style type="text/css">
    .header-order tr td{
        padding: 0px !important;
    }
</style>
<div class="col-lg-12 detail-order">
    <div class="row">
        <div class="col-lg-6">
            <p style="font-weight: bold;">
                CHI TIẾT ĐƠN <?php echo e($bill->id); ?>

            </p>
            <p>
                <?php 
                    $date = date_create($bill->date)
                ?>
                <?php echo e(date_format($date, 'd/m/Y')); ?>

            </p>
        </div>
        <div class="col-lg-6">
            <table class="header-order" style="width: 100%">
                <tr>
                    <td>
                        Khách hàng
                    </td>
                    <td>:</td>
                    <td style="text-align: right;">
                        <span style="font-weight: bold;">
                            <?php echo e($bill->order->customer->full_name); ?>

                        </span>
                    </td>
                </tr>
                <tr>
                    <td>
                        Số dư
                    </td>
                    <td>:</td>
                    <td style="text-align: right; font-weight: bold;">
                        <span><?php echo e(number_format($bill->order->customer->balance)); ?></span><sup>đ</sup>
                    </td>
                </tr>
                <tr>
                    <td>Trạng thái</td>
                    <td>:</td>
                    <td class="status-ajax" style="font-weight: bold; text-align: right;">
                        <?php if($bill->status == config('config.order.status.check-in')): ?>
                            <span style="color: red">Đợi thanh toán</span>
                        <?php elseif($bill->status == config('config.order.status.check-out')): ?>
                            <span style="color: green">Hoàn thành</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
        </div>
    </div><hr>
    <div class="col-lg-12">
        <input type="hidden" id="bill_id" value="<?php echo e($bill->id); ?>" class="id-order" name="">
        <input type="hidden" id="employee_id" value="<?php echo e($bill->order->employee_id); ?>" class="customer-id">
        <input type="hidden" id="price_total" value="<?php echo e($moneyServiceTotal); ?>" name="">
        <table style="width: 100%">
            <?php if($bill->status == config('config.order.status.check-out')): ?>
                <tr>
                    <td style="width: 40%">Đã thanh toán</td>
                    <td style="width: 10%">:</td>
                    <td style="font-weight: bold; width: 50%">
                        <?php echo e(number_format($bill->total)); ?><sup>đ</sup>
                        <input type="hidden" value="<?php echo e($bill->customer->balance); ?>" id="balance" name="">
                    </td>
                </tr>
                <tr>
                    <td>
                        Đánh giá khách hàng
                    </td>
                    <td>
                        :
                    </td>
                    <td style="font-weight: bold;">
                        <?php echo e($bill->rate->name); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Góp ý khách hàng
                    </td>
                    <td>
                        :
                    </td>
                    <td style="font-weight: bold;">
                        <?php echo e($bill->comment); ?>

                    </td>
                </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $serviceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="service-fee" id="service<?php echo e($service->id); ?>">
                    <td>
                        <?php echo e($service->name); ?>

                    </td>
                    <td>:</td>
                    <td style="font-weight: bold;">
                        <?php echo e(number_format($service->price)); ?><sup>d</sup>
                        <input type="hidden" id="hidden<?php echo e($service->id); ?>" value="0" name="">
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <div class="col-lg-12">
        <?php if($bill->status != config('config.order.status.check-out')): ?>
            <button style="float: right; margin-bottom: 20px; height: 50px" type="button" class="add-service btn btn-primary" data-toggle="modal" data-target="#myModal">
                THÊM DỊCH VỤ
            </button>
            <button style="float: left; margin-bottom: 20px; height: 50px; background: #FF9800; border: 0px" type="button" class="add-service btn btn-primary" data-toggle="modal" data-target="#service-other">
                THÊM DỊCH VỤ KHÁC
            </button>
        <?php endif; ?>
        <div class="modal fade" id="service-other">
            <div class="modal-dialog">
              <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                  <h4 class="modal-title">DỊCH VỤ KHÁC</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <table>
                        <tr>
                            <td>
                                Tên dịch vụ
                            </td>
                            <td>
                                :
                            </td>
                            <td>
                                <input type="text" id="service-dif" placeholder="Nhập tên dịch vụ..." class="form-control" name="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Chọn thợ chính
                            </td>
                            <td style="padding: 15px 15px">:</td>
                            <td>
                                <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" id="name-employee-other<?php echo e($employee->id); ?>" value="<?php echo e($employee->full_name); ?>" name="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <select onchange="employeeForServiceOther()" id="employeeForServiceOther" class="option-employee form-control">
                                    <option value="0">Chọn thợ chính</option>
                                    <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->id == $bill->order->employee_id): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo e($employee->id); ?>">
                                            <?php echo e($employee->full_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Chọn thợ phụ
                            </td>
                            <td style="padding: 15px 15px">:</td>
                            <td>
                                <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" id="name-assistant-other<?php echo e($employee->id); ?>" value="<?php echo e($employee->full_name); ?>" name="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <select onchange="employeeAssistantForServiceOther()" id="employee-assistant-for-service-other" class="option-employee form-control">
                                    <option value="0">Chọn thợ phụ</option>
                                    <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->id == $bill->order->employee_id): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo e($employee->id); ?>">
                                            <?php echo e($employee->full_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Giá dịch vụ
                            </td>
                            <td>
                                :
                            </td>
                            <td>
                                <input type="text" id="price-dif" id="formattedNumberField" placeholder="Điền giá dịch vụ..." class="form-control" name="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Chiết khấu (%)
                            </td>
                            <td>:</td>
                            <td>
                                <input type="number" id="percent-dif" placeholder="chiết khấu phần trăm" name="" class="form-control">
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="padding: 15px 15px"></td>
                            <td>
                                <button data-dismiss="modal" style="font-weight: normal; float: left; height: 50px; width: 50%; font-size: 23px; background: #007bff; color: #fff; opacity: 1;" id="add-other-service" class="close btn btn-primary">
                                    THÊM
                                </button>
                            </td>
                        </tr>
                        <script type="text/javascript">
                            function employeeForServiceOther()
                            {
                                id = $('#employeeForServiceOther').val();
                                
                                return id;
                            }
                            function employeeAssistantForServiceOther()
                            {
                                id = $('#employee-assistant-for-service-other').val();
                                
                                return id;
                            }
                            $('#add-other-service').click(function(){
                                var bill_id = $('#bill_id').val();
                                var serviceDif = $('#service-dif').val();
                                var priceDif = $('#price-dif').val();
                                var percentDif = $('#percent-dif').val();
                                var employeeId = employeeForServiceOther();
                                var assistantId = employeeAssistantForServiceOther();
                                var nameEmployee = $('#name-employee-other' + employeeId).val();
                                var nameAssistant = $('#name-assistant-other' + assistantId).val();
                                if (serviceDif == '') {
                                    alert('Cần điền tên dịch vụ');
                                } else if (priceDif == '') {
                                    alert('Cần điền giá dịch vụ'); 
                                } else if (percentDif == '') {
                                    alert('Cần điền % chiết khấu'); 
                                } else if (employeeId == 0) {
                                    alert('Cần chọn thợ chính');
                                } else {
                                    var convertPrice = priceDif.replace(/[,]/g,'');
                                    $.get('admin/hoa-don/dich-vu-khac/them/' + bill_id + '/' + serviceDif + '/' + employeeId + '/' + assistantId + '/' + priceDif + '/' + percentDif, function(data){
                                        if (data != '') {
                                            if (assistantId == 0) {
                                                nameAssistant = '';
                                            }
                                            $('#list-service').append(data);
                                        } else {
                                            alert('Hóa đơn đã được thanh toán, bạn không thể thêm dịch vụ.');
                                        }
                                    });
                                }
                            })
                        </script>
                    </table>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        <div class="modal fade" id="myModal">
            <div class="modal-dialog">
              <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                  <h4 class="modal-title">THÊM DỊCH VỤ</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <table>
                        <tr>
                            <td>
                                Dịch vụ
                            </td>
                            <td style="padding: 15px 15px">
                                :
                            </td>
                            <td>
                                <?php $__currentLoopData = $serviceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input data="<?php echo e($service->price); ?>" type="hidden" id="name-service<?php echo e($service->id); ?>" value="<?php echo e($service->name); ?>" name="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <select class="option-service form-control">
                                    <option value="0">Chọn dịch vụ</option>
                                    <?php $__currentLoopData = $serviceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->id); ?>">
                                            <?php echo e($service->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                                Chọn thợ chính
                            </td>
                            <td style="padding: 15px 15px">:</td>
                            <td>
                                <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" id="name-employee<?php echo e($employee->id); ?>" value="<?php echo e($employee->full_name); ?>" name="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <select onchange="optionEmployee()" id="option-employee" class="option-employee form-control">
                                        <option value="0">Chọn thợ chính</option>
                                    <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->id == $bill->order->employee_id): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo e($employee->id); ?>">
                                            <?php echo e($employee->full_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Chọn thợ phụ
                            </td>
                            <td style="padding: 15px 15px">:</td>
                            <td>
                                <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" id="name-assistant<?php echo e($employee->id); ?>" value="<?php echo e($employee->full_name); ?>" name="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <select onchange="optionAssistant()" class="assistant form-control">
                                        <option value="0">Chọn thợ phụ</option>
                                    <?php $__currentLoopData = $employeeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($employee->id == $bill->order->employee_id): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo e($employee->id); ?>">
                                            <?php echo e($employee->full_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <script type="text/javascript">
                                function optionEmployee()
                                {
                                    var id = $('#option-employee').val();

                                    return id;
                                }
                                function optionAssistant()
                                {
                                    var id = $('.assistant').val();

                                    return id;
                                }
                                stt = 0;
                                $('#formattedNumberField').keyup(function(event) {
                                  // skip for arrow keys
                                  if(event.which >= 37 && event.which <= 40) return;

                                  // format number
                                  $(this).val(function(index, value) {
                                    return value
                                    .replace(/\D/g, "")
                                    .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                                    ;
                                  });
                                });
                                $('#add-service').click(function(){
                                    var pricePrimary = $('#total-all').val();
                                    var serviceId = $('.option-service').val();
                                    var employeeId = optionEmployee();
                                    var assistantId = optionAssistant();
                                    var nameService = $('#name-service' + serviceId).val();
                                    var servicePrice = $('#name-service' + serviceId).attr("data");
                                    var nameEmployee = $('#name-employee' + employeeId).val();
                                    var nameAssistant = $('#name-assistant' + assistantId).val();
                                    var serviceDif = $('#service-dif').val();
                                    var bill_id = $('#bill_id').val();
                                    var priceDif = $('#price-dif').val();
                                    var percentDif = $('#percent-dif').val();

                                    if (serviceId != 0 && employeeId != 0) {
                                        var priceChange = parseInt(pricePrimary) + parseInt(servicePrice);
                                        $.get('admin/hoa-don/dich-vu/them/' + bill_id + '/' + serviceId + '/' + employeeId + '/' + assistantId + '/' + servicePrice, function(data){
                                            if (data != '') {
                                                if (assistantId == 0) {
                                                    nameAssistant = '';
                                                }
                                                $('#list-service').append(data);
                                            } else {
                                                alert('Hóa đơn đã được thanh toán, bạn không thể thêm dịch vụ.');
                                            }
                                        });
                                    } else {
                                        alert('Cần điền đầy đủ thông tin');
                                    }
                                })
                                
                                function xoa(id)
                                {
                                    // price = $('#price' + id).val();
                                    priceTotal = $('#total-all').val();
                                    // $('#total-all').val(parseInt(priceTotal) - parseInt(price));
                                    $.get('admin/hoa-don/xoa/dich-vu/' + id, function(data){
                                        $('#total-all').val(parseInt(priceTotal) - parseInt(data));
                                        if (data != '') {
                                            $('.total-service').html(addCommas(parseInt(priceTotal) - parseInt(data)));
                                            $('#row' + id).remove();
                                        } else {
                                            alert('Hóa đơn đã hoàn thành, bạn không được phép xóa.');
                                        }
                                        
                                    })
                                    
                                }
                            </script>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="padding: 15px 15px"></td>
                            <td>
                                <button data-dismiss="modal" style="font-weight: normal; float: left; height: 50px; width: 50%; font-size: 23px; background: #007bff; color: #fff; opacity: 1;" id="add-service" class="close btn btn-primary">
                                    THÊM
                                </button>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        <table id="list-service">
            <tr>
                <th>Dịch vụ</th>
                <th>Thợ chính</th>
                <th>Thợ phụ</th>
                <th>Giá</th>
            </tr>
            <?php $__currentLoopData = $serviceListUse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($service->service_id != ''): ?> 
                            <?php echo e($service->service->name); ?>

                        <?php else: ?>
                            <?php echo e($service->other_service); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($service->employee->full_name); ?>

                    </td>
                    <td>
                        <?php if($service->assistant_id != ''): ?>
                            <?php echo e($service->employeeAssistant->full_name); ?>

                        <?php endif; ?>
                    </td>
                    <td style="text-align: right;">
                        <?php echo e(number_format($service->money)); ?><sup>đ</sup>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <table style="width: 100%">
            <?php if($bill->status == config('config.order.status.check-out')): ?>
                <tr>
                    <td style="width: 40%">Quà tặng (vnd)</td>
                    <td style="width: 10%">:</td>
                    <td style="font-weight: bold; width: 50%">
                        <?php echo e(number_format($bill->sale)); ?><sup>đ</sup>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td style="width: 40%">
                        Quà tặng (vnd)
                    </td>
                    <td style="width: 10%">:</td>
                    <td style="width: 50%">
                        <input type="text" placeholder="0" value="<?php echo e($bill->sale); ?>" id="sale" class="form-control" name="">
                    </td>
                    
                </tr>
            <?php endif; ?>

            <?php if($bill->status == config('config.order.status.check-out')): ?>
                <tr>
                    <td>Nội dung giảm giá</td>
                    <td>:</td>
                    <td style="font-weight: bold;">
                        <?php echo e(($bill->sale_detail == '') ? 'không có' : $bill->sale_detail); ?>

                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td>
                        Nội dung giảm giá
                    </td>
                    <td>:</td>
                    <td>
                        <input type="text" value="<?php echo e($bill->sale_detail); ?>" class="form-control" placeholder="Nội dùng giảm giá" id="sale_detail" name="">
                    </td>
                </tr>
            <?php endif; ?>

            <!-- <?php if($bill->status != config('config.order.status.check-out')): ?>
                <tr>
                    <td></td>
                    <td></td>
                    <td>
                        <input style="background: #ccc; border: 1px solid #ccc;" class="add-sale btn btn-primary" value="Thêm quà tặng" name="">
                    </td>
                </tr>
            <?php endif; ?> -->
        </table>
    </div>
    <div class="col-lg-12" style="margin-top: 20px">
        <center>
            <?php if($bill->status != config('config.order.status.check-out')): ?>
                <!-- <h2 class="btn btn-primary pay" data-toggle="modal" data-target="#rate">Thanh toán</h2> -->
                <h2 style="width: 100%" data-toggle="modal" data-target="#rate" class="rate pay btn btn-primary">Thanh toán</h2>
                <script type="text/javascript">
                    $('.pay').click(function(){
                        billId = $('#bill_id').val();
                        sale_detail = $('#sale_detail').val();
                        sale = $('#sale').val();
                        $.get('danh-gia/noi-dung/' + billId);
                        $.get('admin/hoa-don/cap-nhat/thu-ngan/' + billId);
                        
                        if (sale == '') {
                            sale = 0;
                        }
                        if (sale_detail == '') {
                            sale_detail = 0;
                        }
                        $.get("admin/hoa-don/thanh-toan/" + billId + '?sale=' + sale + '&saleDetail=' + sale_detail, function(data){
                            $('#modal-body').html(data);
                        });
                        // window.open("admin/hoa-don/thanh-toan/" + billId, "_blank", "width=500, height=600");
                    })
                </script>
            <?php endif; ?>
        </center>
        <div class="modal fade" id="rate">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title">Thanh toán dịch vụ</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body" id="modal-body">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
