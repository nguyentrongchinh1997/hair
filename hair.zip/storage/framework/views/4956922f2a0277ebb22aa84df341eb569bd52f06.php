<?php $__env->startSection('content'); ?>
	<style type="text/css">
		.rate{
			font-size: 100px;
			padding: 0px 10px;
			color: #ccc;
			font-weight: bold;
		}
		table tr td{
			text-align: center;
			padding: 0px 20px;
		}
	</style>
	<script type="text/javascript">
		$(function(){
			$('.rate').click(function(){
				alert("sad");
				$('.rate').css({"color":"#ccc"});
				$(this).css({"color":"yellow"});
				data = $(this).attr('data');
				billId = $('#bill-id').val();
				$.get('khach-hang/danh-gia/' + data + '/' + billId);
				$('#rate-result').html(data);
				$('.title-rate').show();
			})
			$('.comment').click(function(){
				if($(this).is(":checked")) {
					comment = $(this).val();
					billId = $('#bill-id').val();
					$.get('khach-hang/binh-luan/' + comment + '/' + billId);
				}
			})
		})
		
	</script>
	<center>
		<h1>Mời Anh <span style="color: red"><?php echo e($bill->order->customer->full_name); ?></span> Đánh Giá</h1>
		<h3>
			ĐÁNH GIÁ CHẤT LƯỢNG DỊCH VỤ GIÚP CHÚNG EM
		</h3>
		<table>
			<tr>
				<td>
					<i data='rất tệ' class="rate far fa-sad-cry"></i>
					<br><span>RẤT TỆ</span>
				</td>
				<td>
					<i data='tệ' class="rate far fa-sad-tear"></i>
					<br><span>TỆ</span>
				</td>
				<td>
					<i data='bình thường' class="rate far fa-frown-open"></i>
					<br><span>BÌNH THƯỜNG</span>
				</td>
				<td>
					<i data='hài lòng' class="rate far fa-smile"></i>
					<br><span>HÀI LÒNG</span>
				</td>
				<td>
					<i data='rất hài lòng' class="rate far fa-grin-beam"></i>
					<br><span>RẤT HÀI LÒNG</span>
				</td>
			</tr>
		</table>
		<!-- <i data='rất tệ' class="rate far fa-sad-cry"></i>
		<i data='tệ' class="rate far fa-sad-tear"></i>
		<i data='bình thường' class="rate far fa-frown-open"></i>
		<i data='hài lòng' class="rate far fa-smile"></i>
		<i data='rất hài lòng' class="rate far fa-grin-beam"></i> -->
		<input type="hidden" id="bill-id" value="<?php echo e($bill->id); ?>" name="">
		<p>
			<span class="title-rate" style="display: none;">Anh đã chọn: <span style="font-weight: bold; color: green" id="rate-result"></span></span>
		</p>
		<h1>30SHINE NÊN CẢI THIỆN ĐIỀU GÌ ĐỂ ANH HÀI LÒNG HƠN?</h1>
		<table>
			<tr>
				<td>
					<label>
						<input class="comment" value="Tất cả đều tốt, không có góp ý gì;" type="checkbox" name="">
						Tất cả đều tốt, không có góp ý gì
					</label>
				</td>
				<td>
					<label>
						<input class="comment" type="checkbox" value="Chất lượng cắt và kiểu tóc;" name="">
						Chất lượng cắt và kiểu tóc
					</label>
				</td>
			</tr>
			<tr>
				<td>
					<label>
						<input class="comment" value="Thái độ phục vụ;" type="checkbox" name="">
						Thái độ phục vụ
					</label>
				</td>
				<td>
					<label>
						<input class="comment" value="Thời gian chờ đợi;" type="checkbox" name="">
						Thời gian chờ đợi
					</label>
				</td>
			</tr>
			<tr>
				<td>
					<label>
						<input class="comment" value="Nhân viên bớt làm ồn trong khi phục vụ;" type="checkbox" name="">
						Nhân viên bớt làm ồn trong khi phục vụ
					</label>
				</td>
				<td>
					<label>
						<input class="comment" value="Cảm thấy bị làm phiền bởi việc tư vấn dịch vụ/bán hàng;" type="checkbox" name="">
						Cảm thấy bị làm phiền bởi việc tư vấn dịch vụ/bán hàng
					</label>
				</td>
			</tr>
		</table>
	</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.pages.rate.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>