@extends('admin.layouts.index')

@section('content')
trang chủ
@endsection