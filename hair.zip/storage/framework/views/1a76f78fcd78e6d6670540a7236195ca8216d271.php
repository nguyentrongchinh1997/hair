<form method="post" action="<?php echo e(route('employee.edit', ['id' => $oldData->id])); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <table>
        <tr>
            <td>
                Tên nhân viên
                <input type="hidden" value="<?php echo e($oldData->id); ?>" name="id">
            </td>
            <td>
                :
            </td>
            <td>
                <input type="text" class="form-control" required="required" value="<?php echo e($oldData->full_name); ?>" name="full_name">
            </td>
        </tr>
        <tr>
            <td>
                Số điện thoại
            </td>
            <td>
                :
            </td>
            <td>
                <input type="text" class="form-control" required="required" value="<?php echo e($oldData->phone); ?>" name="phone">
            </td>
        </tr>
        <tr>
            <td>
                Vị trí
            </td>
            <td>
                :
            </td>
            <td>
                <select name="service_id" class="form-control">
                    <option <?php if($oldData->service_id == config('config.employee.type.skinner')): ?> <?php echo e('selected'); ?> <?php endif; ?> value="2">Gội</option>
                    <option <?php if($oldData->service_id == config('config.employee.type.stylist')): ?> <?php echo e('selected'); ?> <?php endif; ?> value="1">Cắt</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                Địa chỉ
            </td>
            <td>
                :
            </td>
            <td>
                <input value="<?php echo e($oldData->address); ?>" type="text" class="form-control" name="address">
            </td>
        </tr>
        <tr>
            <td>
                Hoa hồng (%)
            </td>
            <td>
                :
            </td>
            <td>
                <input type="number" value="<?php echo e($oldData->percent); ?>" name="percent" class="form-control">
            </td>
        </tr>
        <tr>
            <td>
                Lương (vnđ)
            </td>
            <td>
                :
            </td>
            <td>
                <input id="format-number" type="text" value="<?php echo e($oldData->salary); ?>" name="salary" class="form-control">
            </td>
        </tr>
        <tr>
            <td>
                Trạng thái
            </td>
            <td>:</td>
            <td>
                <select class="form-control" name="status">
                    <option <?php if($oldData->status == config('config.employee.status.doing')): ?> <?php echo e('selected'); ?> <?php endif; ?> value="1">
                        Đang làm
                    </option>
                    <option <?php if($oldData->status == config('config.employee.status.leave')): ?> <?php echo e('selected'); ?> <?php endif; ?> value="0">
                        Nghỉ làm
                    </option>
                </select>
            </td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
                <input class="btn btn-primary" value="Sửa" type="submit" name="">
            </td>
        </tr>
    </table>
</form>
<script type="text/javascript">
    $('#format-number').keyup(function(event) {
      // skip for arrow keys
      if(event.which >= 37 && event.which <= 40) return;
      // format number
      $(this).val(function(index, value) {
        return value
        .replace(/\D/g, "")
        .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        ;
      });
    });
</script>